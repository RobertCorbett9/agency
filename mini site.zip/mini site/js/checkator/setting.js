(function($) {
    'use strict';
    $("input[type='radio'], input[type='checkbox']").checkator();
})(jQuery);