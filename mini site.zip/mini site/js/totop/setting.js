(function($) {
    'use strict';
    $().UItoTop({
        easingType: 'easeOutQuart'
    });
})(jQuery);